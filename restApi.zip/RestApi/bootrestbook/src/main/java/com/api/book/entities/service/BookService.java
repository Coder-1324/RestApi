package com.api.book.entities.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.api.book.entities.book;


@Component
public class BookService {
    private static List<book> list = new ArrayList<>();


    static{
        list.add(new book(12,"java Complete Reference","xyz"));
        list.add(new book(13,"python Complete Reference","yyy"));
        list.add(new book(14,"C# Complete Reference","zzz"));

    }
    public List<book> getAllBooks(){
        return list;
    }
    public book getBookById(int id){
        book b1=null;


     b1 = list.stream().filter(e->e.getId()==id).findFirst().get();
     return b1;
    }
}
